﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai11
{
    internal class Class1
    {
        private int n;
        public void nhap()
        {
            if (n > 0)
            {
                Console.Write("Nhap so nguyen duong n (>0): ");
                n = Int32.Parse(Console.ReadLine());
            }
        }
        public Boolean kiemtranamnhuan()
        {
            if ((n % 4 == 0 && n % 100 != 0) || (n % 400 == 0))
                return true;
            else
                return false;
        }
    }
}
